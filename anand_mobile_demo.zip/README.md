
Anand Mobile Demo Store — Quick instructions
===========================================

This is a simple static demo website customized for "Anand Mobile".
It is a static HTML/CSS mockup that mimics a Shopify storefront design for demo purposes.

Files inside:
- index.html  -> Main demo page (customized for Anand Mobile)
- styles.css  -> Styling
- README.md   -> This file

How to get a live demo link (2 easy options):
1) Netlify drag-and-drop (fastest):
   - Go to https://app.netlify.com/drop and log in.
   - Drag and drop the unzipped folder. Netlify will give a live link instantly.
   - Replace content in index.html if you want to change text before upload.

2) GitHub Pages:
   - Upload files to a GitHub repo and enable Pages in settings.
   - Your site will be live at https://<username>.github.io/<repo-name>/

Customize quickly:
- Open index.html in any text editor and replace product names/prices as needed.
- To add a logo: replace the .logo text in header with an <img> tag and upload the image.

If you want, I can also:
- Host this for you and provide the live URL (you will need to provide a place to host or credentials).
- Convert this into a one-file HTML (inline CSS) for faster edit before showing clients.
